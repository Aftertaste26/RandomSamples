let accounts = [
    {
        User: 'Kyle@Softer',
        Pass: 'admin',
        firstName: 'Kyle',
        lastName: 'Osunero',
        saveData: [{
            type: "Restaurant",
            name: "Robertos",
            date_ID: 1570287487067
        },
        {
            type: "Milktea",
            name: "Macao Imperial Tea",
            date_ID: 1570287197281
        },
        {
            type: 'Street Food',
            name: 'Jo-ann\'s Fishball',
            date_ID: 1570286690178
        },
        {
            type: 'Fast Food',
            name: 'Mcdonalds',
            date_ID: 1570276015335
        }
        ]
    },
    {
        User: 'Em@Softer',
        Pass: 'admin',
        firstName: 'Edelynn',
        lastName: 'Mallare',
        saveData: [{
            type: "Restaurant",
            name: "Robertos",
            date_ID: 1570289865694
        }
        ]
    },
    {
        User: 'Chem@Softer',
        Pass: 'admin',
        firstName: 'Cherry',
        lastName: 'Jaranilla',
        saveData: []
    }

]

module.exports = accounts

